import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";

const SkillsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  const skills = [
    { name: "JavaScript & TypeScript", level: 90 },
    { name: "React & Next.js", level: 88 },
    { name: "Node.js & Express", level: 85 },
    { name: "HTML5 & CSS3/SCSS", level: 92 },
    { name: "Three.js & WebGL", level: 80 },
    { name: "Unity & C#", level: 82 },
    { name: "Python & Django", level: 78 },
    { name: "AWS & Cloud Services", level: 75 },
    { name: "Docker & Containerization", level: 78 },
    { name: "CI/CD & DevOps", level: 76 },
    { name: "UI/UX Design", level: 85 },
    { name: "Agile & Project Management", level: 88 },
  ];

  const skillCategories = [
    {
      title: "Frontend Development",
      icon: "/images/Frontend.jpg",
      description: "React, Vue, Next.js, TypeScript, HTML5, CSS3/SCSS, TailwindCSS, WebGL, Three.js"
    },
    {
      title: "Backend Development",
      icon: "/images/Server.jpg",
      description: "Node.js, Express, Django, PostgreSQL, MongoDB, GraphQL, REST APIs, Authentication"
    },
    {
      title: "Game Engineering",
      icon: "/images/GameDevelopment.jpg",
      description: "Unity, C#, Game Design, UI Systems, Physics, Shaders, Mobile & Web Game Development"
    },
    {
      title: "DevOps & Deployment",
      icon: "/images/Cloud.jpg",
      description: "AWS, Docker, CI/CD Pipelines, Kubernetes, Performance Optimization, Monitoring"
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="skills" className="py-20 bg-slate-50 relative">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 to-blue-50/30 pointer-events-none"></div>
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">My Skills</h2>
          <div className="w-20 h-1.5 bg-blue-600 mx-auto mb-6 rounded-full"></div>
          <p className="text-lg text-slate-600">I continue to expand my technical expertise through ongoing learning</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 lg:gap-16">
          {/* Skill Categories */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {skillCategories.map((category, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -5 }}
                >
                  <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                    {/* Replace with actual icons or use placeholders */}
                    <span className="text-2xl font-bold">{category.title.charAt(0)}</span>
                  </div>
                  <h3 className="font-semibold text-slate-800 text-center mb-2">{category.title}</h3>
                  <p className="text-sm text-slate-600 text-center">{category.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Progress Bars */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="space-y-5">
              {skills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-slate-800">{skill.name}</span>
                    <span className="text-slate-600">{skill.level}%</span>
                  </div>
                  <Progress 
                    value={isVisible ? skill.level : 0} 
                    className="h-2.5 bg-slate-200"
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;