import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Progress } from "@/components/ui/progress";

const SkillsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  const skills = [
    { name: "Core Java & Spring Boot", level: 90 },
    { name: "JavaScript & TypeScript", level: 85 },
    { name: "Python & C#", level: 80 },
    { name: "Selenium WebDriver & Katalon", level: 95 },
    { name: "Appium Mobile Automation", level: 87 },
    { name: "Cypress, Protractor & Playwright", level: 90 },
    { name: "Rest Assured & API Testing", level: 88 },
    { name: "Git & Version Control", level: 88 },
    { name: "Jenkins & CI/CD", level: 85 },
    { name: "Docker & Containerization", level: 82 },
    { name: "AWS DeviceFarm & Cloud Services", level: 85 },
    { name: "Test Automation Frameworks", level: 92 },
  ];

  const skillCategories = [
    {
      title: "Programming Languages",
      icon: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      description: "Core Java, Spring Boot, JavaScript, TypeScript, C#, Python"
    },
    {
      title: "Testing Frameworks",
      icon: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      description: "Selenium WebDriver, Katalon Studio, Appium Mobile Automation, Cypress, Protractor, Playwright, Cucumber, TestNG, JMeter"
    },
    {
      title: "Cloud & DevOps",
      icon: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      description: "Git, Jenkins CI/CD, Docker, AWS DeviceFarm, S3, Lambda/API Gateway, ECS/EC2, CloudWatch, Amazon-Q, Cedrik, Bedrock, Maven, Gradle"
    },
    {
      title: "API Testing",
      icon: "https://images.unsplash.com/photo-1629654297299-c8506221ca97?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      description: "Rest Assured, Postman, Swagger, BDD, Charles Proxy, Wireshark"
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="skills" className="py-12 sm:py-16 lg:py-20 bg-slate-50">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-4">Skills</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-base sm:text-lg text-slate-600">I am always interested in learning new technologies.</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Skill Categories */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {skillCategories.map((category, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <img 
                    src={category.icon}
                    alt={category.title}
                    className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
                  />
                  <h3 className="font-semibold text-slate-800 text-center mb-2">{category.title}</h3>
                  <p className="text-sm text-slate-600 text-center">{category.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Progress Bars */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="space-y-6">
              {skills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-slate-800">{skill.name}</span>
                    <span className="text-slate-600">{skill.level}%</span>
                  </div>
                  <Progress 
                    value={isVisible ? skill.level : 0} 
                    className="h-3"
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
