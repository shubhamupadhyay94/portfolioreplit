import { motion } from "framer-motion";
import { Award, Code, Globe, Rocket, UserIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const AboutSection = () => {
  const achievements = [
    {
      icon: <Code className="h-5 w-5 text-blue-500" />,
      title: "Full-Stack Development",
      description: "Expertise in building modern web applications with React, Vue, Node.js and various backend technologies"
    },
    {
      icon: <Globe className="h-5 w-5 text-indigo-500" />,
      title: "Web Deployment",
      description: "Proficient in deploying scalable applications using cloud platforms and CI/CD pipelines"
    },
    {
      icon: <Rocket className="h-5 w-5 text-purple-500" />,
      title: "Game Development",
      description: "Skilled in creating interactive games and experiences for web and mobile platforms"
    },
    {
      icon: <Award className="h-5 w-5 text-green-500" />,
      title: "App Engineering",
      description: "Experience in developing cross-platform mobile applications with modern frameworks"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white relative">
      {/* Background subtle pattern */}
      <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:20px_20px]"></div>
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900">About Me</h2>
          <div className="w-20 h-1.5 bg-blue-600 mx-auto mt-4 mb-6 rounded-full"></div>
          <p className="text-slate-600 max-w-3xl mx-auto text-lg">
            Passionate engineer with a focus on creating seamless digital experiences
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-bold text-slate-900 mb-4">Who I Am</h3>
            
            <div className="space-y-4 text-slate-600">
              <p>
                I'm Shubham Upadhyay, a Test Automation Lead with over 10 years of experience in quality assurance and test automation. With a passion for ensuring software quality, I specialize in creating robust automated testing frameworks that enhance application reliability and user experience.
              </p>
              <p>
                My approach combines technical expertise with strategic test planning to build comprehensive test solutions that identify issues early and ensure smooth deployments. I stay current with emerging testing technologies and industry best practices to implement modern, efficient quality assurance processes.
              </p>
              <p>
                I believe in the power of quality-driven development to transform businesses and enhance user satisfaction. Whether I'm developing automated test frameworks, implementing CI/CD pipelines, or leading quality assurance teams, my goal is always to exceed expectations and deliver outstanding quality results.
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                <h4 className="font-semibold text-slate-900 mb-1">Education</h4>
                <p className="text-sm text-slate-600">Master's in Computer Science</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                <h4 className="font-semibold text-slate-900 mb-1">Experience</h4>
                <p className="text-sm text-slate-600">8+ Years in Tech Industry</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-1 gap-4"
          >
            {achievements.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-gradient-to-br from-white to-slate-50">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-slate-100 p-3 rounded-full">
                        {item.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900 mb-1">{item.title}</h4>
                        <p className="text-slate-600 text-sm">{item.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;