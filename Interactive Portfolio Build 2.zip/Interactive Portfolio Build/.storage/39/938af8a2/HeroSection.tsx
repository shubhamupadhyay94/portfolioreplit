import { motion } from "framer-motion";
import { ArrowRight, Download, Github, Linkedin, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden pt-16">
      {/* Background gradient elements */}
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-400 rounded-full opacity-10 blur-3xl"></div>
      <div className="absolute top-1/4 -left-40 w-96 h-96 bg-indigo-400 rounded-full opacity-10 blur-3xl"></div>
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="order-2 lg:order-1"
        >
          <div className="space-y-6">
            <div>
              <motion.p 
                className="text-lg text-blue-600 font-medium mb-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                Hello, I'm
              </motion.p>
              <motion.h1 
                className="text-4xl sm:text-5xl md:text-6xl font-bold text-slate-900 leading-tight"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                Shubham <span className="text-blue-600">Upadhyay</span>
              </motion.h1>
              <motion.h2 
                className="text-xl sm:text-2xl md:text-3xl font-medium text-slate-700 mt-3"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                Test Automation Lead
              </motion.h2>
            </div>
            
            <motion.p 
              className="text-slate-600 text-lg leading-relaxed max-w-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              A highly passionate Test Automation Lead with over 10 years of experience in testing 
              software applications within Agile environments across various domains, including Amazon 
              Appstore, Prime Video, investment banking, procurement, and fleet management.
            </motion.p>
            
            {/* Social Links */}
            <motion.div 
              className="flex gap-3 pt-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <a href="https://github.com/shubhamupadhyay09" className="text-slate-600 hover:text-blue-600 transition-colors">
                <Github className="w-5 h-5" />
                <span className="sr-only">GitHub</span>
              </a>
              <a href="https://www.linkedin.com/in/shubhamupadhyay09/" className="text-slate-600 hover:text-blue-600 transition-colors">
                <Linkedin className="w-5 h-5" />
                <span className="sr-only">LinkedIn</span>
              </a>
              <a href="#contact" className="text-slate-600 hover:text-blue-600 transition-colors">
                <Mail className="w-5 h-5" />
                <span className="sr-only">Email</span>
              </a>
            </motion.div>
            
            {/* CTA Buttons */}
            <motion.div 
              className="flex flex-col sm:flex-row gap-3 pt-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
            >
              <Button
                onClick={scrollToAbout}
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
                size="lg"
              >
                Explore My Work
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              
              <Button 
                variant="outline"
                className="border-blue-600 text-blue-600 hover:bg-blue-50"
                size="lg"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </motion.div>
          </div>
        </motion.div>
        
        <motion.div 
          className="order-1 lg:order-2 flex justify-center items-center"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div className="relative">
            {/* Decorative elements */}
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-blue-200 rounded-full opacity-60 blur-md"></div>
            <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-indigo-200 rounded-full opacity-60 blur-md"></div>
            
            <div className="relative z-10 bg-gradient-to-br from-white to-blue-50 p-2 rounded-2xl shadow-xl">
              <img
                src="https://images.unsplash.com/photo-1617040619263-41c5a9ca7521?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
                alt="Alex Engineer"
                className="w-full max-w-sm rounded-xl object-cover shadow-inner transform rotate-1"
              />
            </div>
            
            {/* Floating elements */}
            <motion.div
              className="absolute -right-4 top-1/4 bg-white p-2 rounded-lg shadow-lg flex items-center gap-2"
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            >
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-xs font-medium">Test Automation</span>
            </motion.div>
            
            <motion.div
              className="absolute -left-6 bottom-1/4 bg-white p-2 rounded-lg shadow-lg flex items-center gap-2"
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut", delay: 0.5 }}
            >
              <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
              <span className="text-xs font-medium">Quality Assurance</span>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;