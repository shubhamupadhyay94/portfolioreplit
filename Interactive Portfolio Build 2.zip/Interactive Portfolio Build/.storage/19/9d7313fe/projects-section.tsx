import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";

const ProjectsSection = () => {
  const projects = [
    {
      title: "Custom Automation Frameworks",
      description: "Designed and developed custom test automation frameworks for Amazon Prime Video live events, enhancing reliability and test coverage.",
      image: "https://miro.medium.com/v2/resize:fit:4800/format:webp/1*fJjQOPz-PdJjRqefaBV13Q.jpeg",
      tags: ["Live Events", "Automation", "Prime Video"],
      githubLink: "https://github.com/shubhamupadhyay94",
      features: [
        "Built scalable frameworks for multi-platform testing",
        "Reduced manual testing efforts by 70%",
        "Enhanced test coverage for live sports events",
        "Implemented CI/CD pipeline integration"
      ]
    },
    {
      title: "API Automation with BDD",
      description: "Implemented a robust API automation strategy using Rest Assured and a BDD approach for critical financial services at Morgan Stanley.",
      image: "https://educationecosystem.com/blog/wp-content/uploads/2021/11/Test-Automation-Frameworks.png",
      tags: ["Rest Assured", "BDD", "API Testing", "Java"],
      githubLink: "https://github.com/shubhamupadhyay94",
      features: [
        "Comprehensive API test coverage",
        "BDD framework implementation",
        "Integration with financial systems",
        "Automated regression testing"
      ]
    },
    {
      title: "Multilingual Framework",
      description: "Engineered a multilingual framework at Zycus to significantly increase test coverage across different languages and regions.",
      image: "https://kms-technology.com/wp-content/uploads/2022/05/iStock-1321462048-1-scaled.jpg",
      tags: ["i18n", "Framework", "Test Coverage"],
      githubLink: "https://github.com/shubhamupadhyay94",
      features: [
        "Support for multiple languages",
        "Automated localization testing",
        "Enhanced global product quality",
        "Keyword-driven test automation"
      ]
    }
  ];

  return (
    <section id="projects" className="py-12 sm:py-16 lg:py-20 bg-white">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-4">Featured Projects</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto">
            Here are some of the projects I'm proud of. Each one showcases my ability to solve problems and deliver high-quality automation solutions.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              className="bg-slate-50 rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4">
                    <a
                      href={project.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-white hover:text-gray-200 transition-colors"
                    >
                      <Github size={20} className="mr-2" />
                      View on GitHub
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3">{project.title}</h3>
                <p className="text-slate-600 mb-4 leading-relaxed">{project.description}</p>
                
                <div className="mb-4">
                  <h4 className="font-semibold text-slate-800 mb-2">Key Features:</h4>
                  <ul className="space-y-1">
                    {project.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start text-sm text-slate-600">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 mr-2 flex-shrink-0"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, idx) => (
                    <span 
                      key={idx}
                      className="px-3 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <a
                  href={project.githubLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-primary hover:text-blue-700 font-medium transition-colors"
                >
                  <ExternalLink size={16} className="mr-2" />
                  Learn More
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;