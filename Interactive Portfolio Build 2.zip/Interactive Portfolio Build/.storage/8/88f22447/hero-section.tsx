import { motion } from "framer-motion";
import { Download, ArrowRight } from "lucide-react";
import { SiLinkedin, SiGithub, SiWhatsapp } from "react-icons/si";
import { FaUserTie, FaBriefcase } from "react-icons/fa";

const HeroSection = () => {
  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center bg-gradient-to-br from-slate-50 to-blue-50 pt-16 sm:pt-20">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <p className="text-lg text-slate-600 mb-2">Hi, I am</p>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 mb-4 leading-tight">
            Shubham <span className="text-primary">Upadhyay.</span>
          </h1>
          <h2 className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-medium text-slate-700 mb-6">Test Automation Lead.</h2>
          <p className="text-base sm:text-lg text-slate-600 mb-6 sm:mb-8 max-w-lg leading-relaxed">
            A highly passionate Test Automation Lead with over 10 years of experience in testing software applications within Agile 
            environments across various domains, including Amazon Appstore, Prime Video, investment banking, procurement, 
            and fleet management. I have strong expertise in developing automation frameworks and scripts for Web, API, and 
            Mobile applications using a wide range of tools and technologies.
          </p>
          
          {/* Social Media Section */}
          <div className="mb-6 sm:mb-8">
            <p className="text-xs sm:text-sm text-slate-500 mb-3 sm:mb-4 font-medium">Connect with me:</p>
            <div className="flex gap-2 sm:gap-3 overflow-x-auto pb-2">
              <a
                href="https://www.linkedin.com/in/shubhamupadhyay1/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 sm:gap-2 bg-gradient-to-r from-blue-500/80 to-blue-600/80 text-white px-3 sm:px-4 py-2 sm:py-3 rounded-lg hover:from-blue-600 hover:to-blue-700 hover:shadow-lg transition-all duration-300 group transform hover:scale-105 opacity-90 hover:opacity-100 min-w-0 flex-shrink-0"
              >
                <SiLinkedin className="group-hover:scale-110 transition-transform" size={18} />
                <span className="text-xs sm:text-sm font-semibold whitespace-nowrap">LinkedIn</span>
              </a>
              <a
                href="https://www.preplaced.in/profile/shubham-upadhyay"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 sm:gap-2 bg-gradient-to-r from-orange-500/80 to-orange-600/80 text-white px-3 sm:px-4 py-2 sm:py-3 rounded-lg hover:from-orange-600 hover:to-orange-700 hover:shadow-lg transition-all duration-300 group transform hover:scale-105 opacity-90 hover:opacity-100 min-w-0 flex-shrink-0"
              >
                <FaBriefcase className="group-hover:scale-110 transition-transform" size={16} />
                <span className="text-xs sm:text-sm font-semibold whitespace-nowrap">Preplaced</span>
              </a>
              <a
                href="https://wa.me/917050405737"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 sm:gap-2 bg-gradient-to-r from-green-500/80 to-green-600/80 text-white px-3 sm:px-4 py-2 sm:py-3 rounded-lg hover:from-green-600 hover:to-green-700 hover:shadow-lg transition-all duration-300 group transform hover:scale-105 opacity-90 hover:opacity-100 min-w-0 flex-shrink-0"
              >
                <SiWhatsapp className="group-hover:scale-110 transition-transform" size={18} />
                <span className="text-xs sm:text-sm font-semibold whitespace-nowrap">WhatsApp</span>
              </a>
              <a
                href="https://github.com/shubhamupadhyay-engineer"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 sm:gap-2 bg-gradient-to-r from-gray-700/80 to-gray-800/80 text-white px-3 sm:px-4 py-2 sm:py-3 rounded-lg hover:from-gray-800 hover:to-gray-900 hover:shadow-lg transition-all duration-300 group transform hover:scale-105 opacity-90 hover:opacity-100 min-w-0 flex-shrink-0"
              >
                <SiGithub className="group-hover:scale-110 transition-transform" size={18} />
                <span className="text-xs sm:text-sm font-semibold whitespace-nowrap">GitHub</span>
              </a>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <button
              onClick={scrollToAbout}
              className="bg-primary text-white px-4 sm:px-5 py-2.5 sm:py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center gap-1 min-h-[44px] w-full sm:w-auto"
              style={{ touchAction: 'manipulation' }}
            >
              Know More
              <ArrowRight size={16} />
            </button>
            <a
              href="https://drive.google.com/uc?export=download&id=1c-ZXoYaZWrjtyKvn42kawiyQLcEInFnt"
              target="_blank"
              rel="noopener noreferrer"
              className="border-2 border-primary text-primary px-3 sm:px-4 py-2.5 sm:py-2 rounded-lg hover:bg-primary hover:text-white transition-colors text-sm font-medium flex items-center justify-center gap-1 min-h-[44px] w-full sm:w-auto"
              style={{ touchAction: 'manipulation' }}
            >
              <Download size={14} />
              Download CV
            </a>
            <a
              href="https://drive.google.com/uc?export=download&id=1gWlpatpnTXMmhOj_V58D4i0DWiVMWkts"
              target="_blank"
              rel="noopener noreferrer"
              className="border-2 border-slate-600 text-slate-600 px-3 sm:px-4 py-2.5 sm:py-2 rounded-lg hover:bg-slate-600 hover:text-white transition-colors text-sm font-medium flex items-center justify-center gap-1 min-h-[44px] w-full sm:w-auto"
              style={{ touchAction: 'manipulation' }}
            >
              <Download size={14} />
              Cover Letter
            </a>
          </div>
        </motion.div>
        
        <motion.div 
          className="flex justify-center lg:justify-end order-first lg:order-last"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <img 
            src="https://i.postimg.cc/K4XQpxBM/db915b32-cc4d-4b45-afc4-67a55ccad157.jpg" 
            alt="Shubham Upadhyay - Test Automation Lead" 
            className="rounded-2xl shadow-2xl w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
