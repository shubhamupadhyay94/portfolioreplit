import { motion } from "framer-motion";
import { Calendar, MapPin, Building } from "lucide-react";

const ExperienceSection = () => {
  const experiences = [
    {
      title: "Test Lead (QAE2)",
      company: "Amazon Appstore & Prime Video",
      location: "Bengaluru",
      period: "June 2022 - Present",
      projects: "Amazon Appstore, Prime Video",
      responsibilities: [
        "Develop and maintain test automation frameworks, scripts, and execution across multiple pipelines for Web, Mobile, and API testing",
        "Implement comprehensive AWS cloud infrastructure leveraging Device Farm, S3, Lambda/API Gateway, ECS/EC2, CloudWatch, and AI-powered tools (Amazon-Q, Cedrik, Bedrock)",
        "Lead product testing for Two-Way Developer Communication, Multi-Lat Feature Testing, SEV-2 issue validation, impact analysis, and patch production deployment",
        "Manage customer facing critical product launches from requirement gathering to production deployment, including test planning, automation strategy, and production sanity checks",
        "Conduct Prime Video Live sports X-Ray testing on Android (Phones/Tablets), iPhone/iPad, Fire TV, Roku TV, Apple TV, Windows, and Mac devices",
        "Oversee Bi-Weekly Release Testing, Pre-Season Testing, and testing for new features and sports across Android, iOS, Web, and Windows platforms",
        "Manage comprehensive testing for Slingshot architecture, RG Sports, Premier League, NBA, Soccer Scoreboard, TNF Nametag and Spotlight (ML Based Module)",
        "Successfully executed performance testing initiatives for Prime Video and Amazon Appstore utilizing TPS Generator"
      ]
    },
    {
      title: "Sr. SDET",
      company: "Morgan Stanley",
      location: "Mumbai",
      period: "Dec 2019 - May 2022",
      projects: "Investment Banking Applications",
      responsibilities: [
        "Developed and maintained automation frameworks, including script creation, execution, and maintenance for web applications, mobile platforms, and APIs",
        "Reviewed end-to-end (E2E) automation suites, enhancing coverage by adding missing scenarios, updating test data, and incorporating test cases for fixed bugs",
        "Conducted manual API testing using Swagger and Postman, and implemented API automation using Java, Rest Assured, TestNG, and BDD",
        "Authored Gherkin scripts for new features and collaborated with the Business Team for reviews and validation",
        "Led knowledge transfer (KT) sessions and automation learning programs for onboarding new team members",
        "Performed comprehensive E2E testing, covering functional, database, API, UI, integration, load, email, job, and concurrent testing",
        "Worked extensively on critical and data security features to ensure compliance and risk mitigation",
        "Created and shared Jive documentation on Protractor and Cypress automation setup across the organization"
      ]
    },
    {
      title: "SDET",
      company: "Zycus Infotech",
      location: "Mumbai",
      period: "May 2018 - Oct 2019",
      projects: "Procurement Solutions",
      responsibilities: [
        "Served as a COE Member, leading web and API framework development and maintenance across multiple products",
        "Collaborated with various automation teams to troubleshoot and resolve framework-related issues",
        "Designed, developed, maintained, and executed automation frameworks for web applications and APIs",
        "Revamped the entire framework to implement multilingual support across all test cases",
        "Enhanced sanity and regression suites to achieve a 100% success rate",
        "Executed nightly automation test suites, performed root cause analysis (RCA) for failed test cases",
        "Developed a comprehensive product health check sanity suite from scratch",
        "Built complex keyword-driven features to reduce manual effort and improve efficiency"
      ]
    },
    {
      title: "Software Test Engineer",
      company: "Capgemini",
      location: "Bengaluru",
      period: "June 2015 - April 2018",
      projects: "Fleet Management Applications",
      responsibilities: [
        "Completed comprehensive 3-month Full Stack Java Development training from Capgemini covering Core Java, Spring Boot, Hibernate, REST APIs, and modern development practices",
        "Test case creation, execution review and status reporting of executed test case results",
        "Created sanity and automation script using Java, Selenium WebDriver, Rainbow Framework, TestNG and Maven",
        "Discussion with SIT testing team regarding missed scenario and caught defect by automation testing suite",
        "Identification of defects, defect logging and management in Rally (CA Agile)",
        "Fixing of automation scripts failing due to application modifications",
        "Interaction with client and business analysts to understand requirement and reporting defects",
        "Worked on UI Testing, Function Testing and Data testing of application for different modules",
        "Involved in requirement gathering, test case creation and execution of test case"
      ]
    }
  ];

  return (
    <section id="experience" className="py-12 sm:py-16 lg:py-20 bg-slate-50">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-4">My Experience</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-slate-300"></div>
          
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                className="relative pl-20"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                {/* Timeline dot */}
                <div className="absolute left-6 w-4 h-4 bg-primary rounded-full border-4 border-white shadow-lg"></div>
                
                <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-slate-900 mb-2">{exp.title}</h3>
                      <div className="flex items-center text-primary font-medium text-lg mb-2">
                        <Building size={18} className="mr-2" />
                        {exp.company}
                      </div>
                      <div className="flex items-center text-slate-600 mb-2">
                        <MapPin size={16} className="mr-2" />
                        {exp.location}
                      </div>
                      {exp.projects && (
                        <p className="text-slate-600 font-medium">Projects: {exp.projects}</p>
                      )}
                    </div>
                    <div className="flex items-center bg-primary text-white px-4 py-2 rounded-full mt-4 lg:mt-0">
                      <Calendar size={16} className="mr-2" />
                      <span className="font-medium text-sm">{exp.period}</span>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3">Key Responsibilities:</h4>
                    <ul className="space-y-2">
                      {exp.responsibilities.map((responsibility, idx) => (
                        <li key={idx} className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                          <span className="text-slate-600 leading-relaxed">{responsibility}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
