import { motion } from "framer-motion";
import { Download, GraduationCap, MapPin, Calendar, Award } from "lucide-react";

const AboutSection = () => {
  return (
    <section id="about" className="py-12 sm:py-16 lg:py-20 bg-white">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-4">About Me</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <p className="text-base sm:text-lg text-slate-600 mb-4 sm:mb-6 leading-relaxed">
              A highly passionate Test Automation Lead with over 10 years of experience in testing software applications within Agile 
              environments across various domains, including Amazon Appstore, Prime Video, investment banking, procurement, 
              and fleet management. I have strong expertise in developing automation frameworks and scripts for Web, API, and 
              Mobile applications using a wide range of tools and technologies.
            </p>
            <p className="text-base sm:text-lg text-slate-600 mb-4 sm:mb-6 leading-relaxed">
              Currently working at Amazon as a Test Automation Lead (QAE2), I specialize in comprehensive AWS cloud infrastructure 
              leveraging Device Farm, S3, Lambda/API Gateway, ECS/EC2, and CloudWatch. I utilize AI-powered tools like 
              Amazon-Q, Cedrik, and Bedrock to streamline test planning and scenario generation.
            </p>
            <p className="text-base sm:text-lg text-slate-600 mb-6 sm:mb-8 leading-relaxed">
              I have a strong background in leading and mentoring QA teams while actively creating and executing test plans, 
              designing automation strategies, resolving blockers, and ensuring clear stakeholder communication to deliver 
              high-quality, zero-escape product releases on time.
            </p>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5 mb-5">
              {/* Education Section */}
              <motion.div 
                className="bg-gradient-to-br from-blue-50 to-indigo-50 p-3 sm:p-4 rounded-xl border border-blue-100 shadow-lg hover:shadow-xl transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center mb-2">
                  <div className="bg-blue-500 p-2 rounded-full mr-2">
                    <GraduationCap className="text-white" size={18} />
                  </div>
                  <h3 className="text-base font-bold text-slate-900">Education</h3>
                </div>
                
                <div className="space-y-2">
                  <div className="bg-white/60 backdrop-blur-sm p-2.5 rounded-lg border border-white/40">
                    <div className="flex items-start space-x-2">
                      <Award className="text-blue-600 mt-0.5 flex-shrink-0" size={14} />
                      <div>
                        <h4 className="font-semibold text-slate-800 text-xs">MBA Information Technology</h4>
                        <p className="text-slate-600 text-xs">Bharati Vidyapeeth University</p>
                        <div className="flex items-center text-xs text-slate-500">
                          <Calendar size={8} className="mr-1" />
                          <span>Post Graduate</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/60 backdrop-blur-sm p-2.5 rounded-lg border border-white/40">
                    <div className="flex items-start space-x-2">
                      <Award className="text-blue-600 mt-0.5 flex-shrink-0" size={14} />
                      <div>
                        <h4 className="font-semibold text-slate-800 text-xs">BSc Information Technology</h4>
                        <p className="text-slate-600 text-xs">Mumbai University</p>
                        <div className="flex items-center text-xs text-slate-500">
                          <Calendar size={8} className="mr-1" />
                          <span>Bachelor's</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Location Section */}
              <motion.div 
                className="bg-gradient-to-br from-emerald-50 to-teal-50 p-3 sm:p-4 rounded-xl border border-emerald-100 shadow-lg hover:shadow-xl transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center mb-2">
                  <div className="bg-emerald-500 p-2 rounded-full mr-2">
                    <MapPin className="text-white" size={18} />
                  </div>
                  <h3 className="text-base font-bold text-slate-900">Current Location</h3>
                </div>
                
                <div className="bg-white/60 backdrop-blur-sm p-2.5 rounded-lg border border-white/40">
                  <div className="space-y-1.5">
                    <div>
                      <h4 className="font-semibold text-slate-800 text-xs">Bengaluru, India</h4>
                      <p className="text-slate-600 text-xs">Royal Building, Mahadevpura</p>
                      <p className="text-slate-600 text-xs">Whitefield, Bengaluru, Karnataka</p>
                    </div>
                    
                    <div className="pt-1.5 border-t border-emerald-100">
                      <a
                        href="https://maps.google.com/?q=Mahadevpura,Bengaluru,Karnataka"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-emerald-600 hover:text-emerald-700 font-medium transition-colors text-xs group"
                        style={{ touchAction: 'manipulation' }}
                      >
                        <MapPin size={10} className="mr-1 group-hover:scale-110 transition-transform" />
                        View on Google Maps
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
            

          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
