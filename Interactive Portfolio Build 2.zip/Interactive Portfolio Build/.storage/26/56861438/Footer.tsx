import { motion } from "framer-motion";
import { ArrowUp } from "lucide-react";
import { SiLinkedin, SiGithub, SiWhatsapp } from "react-icons/si";
import { FaUserTie, FaBriefcase } from "react-icons/fa";

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const socialLinks = [
    { 
      icon: <SiLinkedin size={24} />, 
      href: "https://www.linkedin.com/in/shubhamupadhyaysdet", 
      label: "LinkedIn",
      color: "hover:text-blue-400"
    },
    { 
      icon: <FaBriefcase size={22} />, 
      href: "https://www.preplaced.in/profile/shubham-upadhyay", 
      label: "Preplaced",
      color: "hover:text-orange-400"
    },
    { 
      icon: <SiWhatsapp size={24} />, 
      href: "https://wa.me/918452978234", 
      label: "WhatsApp",
      color: "hover:text-green-400"
    },
    { 
      icon: <SiGithub size={24} />, 
      href: "https://github.com/shubhamupadhyay94", 
      label: "GitHub",
      color: "hover:text-gray-300"
    },
    { 
      icon: <FaUserTie size={22} />, 
      href: "https://bold.pro/my/shubham-upadhyay-250528144317", 
      label: "Bold Profile",
      color: "hover:text-purple-400"
    },
  ];

  return (
    <footer className="bg-gradient-to-br from-slate-900 to-slate-800 text-white py-16 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-30">
        <div className="w-full h-full bg-gradient-to-tr from-blue-900/10 to-purple-900/10"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="grid md:grid-cols-3 gap-8 md:gap-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          {/* Brand Section */}
          <div className="md:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Shubham Upadhyay
              </h3>
              <p className="text-slate-300 mb-4 leading-relaxed">
                Test Automation Lead passionate about delivering quality software solutions
              </p>
              <p className="text-slate-400 text-sm">© 2025 All Rights Reserved</p>
            </motion.div>
          </div>
          
          {/* Social Media Section */}
          <div className="md:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h4 className="text-lg font-semibold mb-6 text-slate-200">Connect With Me</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                {socialLinks.map((link, index) => (
                  <motion.a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`group flex flex-col items-center p-4 bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 transition-all duration-300 hover:border-slate-600 hover:bg-slate-700/50 hover:shadow-lg hover:shadow-slate-900/20 text-slate-400 ${link.color} min-h-[80px] justify-center`}
                    aria-label={link.label}
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    style={{ touchAction: 'manipulation' }}
                  >
                    <div className="mb-2 group-hover:scale-110 transition-transform">
                      {link.icon}
                    </div>
                    <span className="text-xs font-medium text-center group-hover:font-semibold transition-all">
                      {link.label}
                    </span>
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
        
        {/* Scroll to Top Button */}
        <motion.div 
          className="mt-12 text-center border-t border-slate-700/50 pt-8"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <motion.button
            onClick={scrollToTop}
            className="group relative inline-flex items-center justify-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-full shadow-lg hover:shadow-xl transition-all duration-300 min-h-[44px]"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            style={{ touchAction: 'manipulation' }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            <ArrowUp size={20} className="mr-2 group-hover:animate-bounce" />
            <span className="relative z-10">Back to Top</span>
          </motion.button>
          
          <p className="mt-4 text-slate-400 text-sm">
            Made with ❤️ for quality automation
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;